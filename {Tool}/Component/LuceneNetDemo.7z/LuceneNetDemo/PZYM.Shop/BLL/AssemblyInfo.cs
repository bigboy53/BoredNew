using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;


[assembly: AssemblyTitle("Maticsoft.Web ����ṹʾ��Դ��")]
[assembly: AssemblyDescription("Maticsoft.Web ����ṹʾ��Դ��")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Maticsoft")]
[assembly: AssemblyProduct("Maticsoft.Web ����ṹʾ��Դ��")]
[assembly: AssemblyCopyright("Copyright (C) Maticsoft 2004-2008")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("2.0.0.0")]